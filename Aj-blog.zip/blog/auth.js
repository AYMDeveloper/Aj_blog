
//Listen to auth staus changes

auth.onAuthStateChanged(user => {

    if (user) {
        //Get data
        db.collection('news').onSnapshot(snapshot => {
            setupNews(snapshot.docs)
            setupUI(user)
        })
        
        //update displayName
        
    }else{
        setupNews([])
        setupUI()
    }
    
})

//Add new news
const addNewsForm = document.querySelector('#add-news-form')
      if(addNewsForm){

    addNewsForm.addEventListener('submit', (e) => {

        e.preventDefault()

        db.collection('news').add({
            title: addNewsForm['news-title'].value,
            subText: addNewsForm['subtext'].value,
            text: addNewsForm['text'].value,
            author: firebase.auth().currentUser.displayName,
              date: nowDate, 
              authorImage: firebase.auth().currentUser.photoURL, 
              uid: firebase.auth().currentUser.uid
        }).then(() => {
          firebase.firestore()
.collection('users')
.doc(firebase.auth().currentUser.uid)
.update({
  articles: articles.push(firebase.auth().currentUser.uid)
})
        }).then(() => {
            location.replace('../index.html')
        })
    })
}



//sign up
const signupForm = document.querySelector('#singup-form')
if(signupForm){
    signupForm.addEventListener('submit', (e) => {
        e.preventDefault()

        //get users info
        const name = document.querySelector('#fName').value
        const email = document.querySelector('#signup-email').value
        const password = signupForm['signup-password'].value
        const passRep = signupForm['pass-rep'].value
        
        //sign the user up
        auth.createUserWithEmailAndPassword(email, password).then((cred) => {
          //return firebase.auth().currentUser.updateProfile({
           // displayName: name
          //})
         return  db.collection('users').doc(cred.user.uid).set({
            firestName: name, 
            lastName: signupForm['lName'].value, 
            articles: []
    }); 
        }).then(() => {
          signupForm.reset()
          location.replace('../index.html')
        })
    })
}

//logout
const logut = document.querySelector('#logout')
if(logut){
    logut.addEventListener('click', (e) => {
        e.preventDefault()
        auth.signOut()
    })
}


//Logging the user in
const loginForm = document.querySelector('#login-form')
if(loginForm){
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault()

        //Get users info
        const email = loginForm['login-email'].value
        const password = loginForm['login-password'].value

        //Sing in the users
        auth.signInWithEmailAndPassword(email, password).then( () =>{
            location.replace('../index.html')
            signupForm.reset()
        })
    })
}