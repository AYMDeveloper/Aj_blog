const newsList = document.querySelector('section')

const loggedIn = document.querySelectorAll('.logged-in')

const loggedOut = document.querySelectorAll('.logged-out')
const accountName = document.querySelector('.account-name')

const setupUI = (user) => {
    if (user) {
        // account info
        accountName.innerText = user.displayName
        //toggel UI elements
        loggedIn.forEach(item => item.style.display = 'inline-block')
        loggedOut.forEach(item => item.style.display = 'none')
    } else {
        //hide account info
        accountName.innerText = ''
        //toggel UI elements
        loggedIn.forEach(item => item.style.display = 'none')
        loggedOut.forEach(item => item.style.display = 'inline-block')
    }
}

//Setup news
const setupNews = (data) => {

    if(data.length){
        let html = ''
        data.forEach(doc => {
            const news = doc.data()
            const li = `
            <div class="postContainer">
                <img class="postI" src="image/poster.jpeg" alt="Turkish war ships">
                    <div class="rScn">
                        <h1>${news.title}</h1>
                        <div class="sub">${news.subText}</div>
                        <div class="postInfo">
                            <div class="info">
                                <svg class="icon icon--aj-logo icon--white icon--24 icon--aj-logo" viewBox="0 0 20 20" version="1.1" aria-hidden="true"><title>aj-logo</title><path class="icon-main-color" d="M11.61 17.51v.14c0 .07.13.36.13.36a1.32 1.32 0 0 0 .38.61c.19.14.29.09.33.08a.28.28 0 0 0 .1-.3 1.43 1.43 0 0 0-.11-.35c0-.08-.08-.13-.11-.11s0 .07 0 .12a.15.15 0 0 1-.09.16c-.05 0-.19.08-.29-.12a2.75 2.75 0 0 1-.19-.44c0-.07-.07-.15-.11-.15zm-3 .58l.63.55.61-.78-.63-.55-.61.78zm.14-1.36l.63.54.62-.77-.6-.5-.61.78zm4-1.92l.74.37.41-.92-.74-.36-.41.91zM9 14.17a5.41 5.41 0 0 0 1.33 1.93 6.42 6.42 0 0 1 .18-.89 4.23 4.23 0 0 1-1.21-1.33l-.3.29zm1.4-1l.74.36.41-.91-.74-.37-.41.92zM6.82 9.54a2.33 2.33 0 0 0-.65.8 1.1 1.1 0 0 0 0 .73c.07.15.22.29.42.12a.74.74 0 0 0 .23-.42.92.92 0 0 0 0-.18c0-.05 0-.1-.07-.08s0 .23-.15.32a.2.2 0 0 1-.29-.17.85.85 0 0 1 .23-.61 4.32 4.32 0 0 1 .36-.39s.16-.14.11-.21H7c-.05 0-.16.1-.16.1zM11.36 9l-.57.65-.49.57c-.11.12-.17.25-.15.31l.06.34a1 1 0 0 1 .17-.27l.56-.65.49-.57c.11-.12.17-.24.15-.31l-.06-.34a1.17 1.17 0 0 1-.16.27zm-6.15 5a1.22 1.22 0 0 1 .54-.74c.46-.23.64.36.64.36a.62.62 0 0 1-.63.6.8.8 0 0 1-.55-.22zm3.46-9.56a.61.61 0 0 0 0 1.21.57.57 0 0 0 .42-.22 1.47 1.47 0 0 1-.67 1.32C8 7.19 6.74 7.79 5.88 8.52a4.16 4.16 0 0 0-1.59 3 5 5 0 0 0 .13 1.36 6 6 0 0 0 .32 1v.05a6.22 6.22 0 0 0 .35 2.41c.42 1 1.19 1.84 2.29 1.6s1.23-2.18 1.36-3.57c0-.23.06-.27.13-.32s.61-.59.82-.78a1.27 1.27 0 0 0 .31-.39.78.78 0 0 0 0-.43l-.12-.91a1.46 1.46 0 0 1-.4.53c-.22.24-.81.77-.86.83s-.25.2-.33.9c-.21 1.9-.57 2.8-1.2 3.1a1.49 1.49 0 0 1-.57.13c-1.17 0-1.47-1.51-1.47-2.34a.71.71 0 0 1 0-.14 1.27 1.27 0 0 0 1.16.69c.79-.13.55-1.53.43-1.85s-.42-1.31-1.08-1.26c-.47 0-.68.61-.78 1.1A4.1 4.1 0 0 1 4.74 12a4.18 4.18 0 0 1 1.51-2.93C7.09 8.33 8 7.8 8.56 7.36a2.34 2.34 0 0 0 .66-.88 4.63 4.63 0 0 1-.22.95c-.5 1.34-2 3.57-2 6.7a13.13 13.13 0 0 0 .23 2.52 1.25 1.25 0 0 0 .23-.23 8.69 8.69 0 0 1-.16-1.67c0-3.14 1.46-5.36 1.94-6.7a4.65 4.65 0 0 0 .26-1.73 4.41 4.41 0 0 0-.25-1.53.59.59 0 0 0-.55-.35zm1.44-4.3a1.8 1.8 0 0 0-.54 1.46A3.56 3.56 0 0 0 10 3.24a1.94 1.94 0 0 0-.35 1.82c.15.44.22.55.29.81a4.52 4.52 0 0 1-.52 2.7 8.72 8.72 0 0 0-.92 3.32 6.11 6.11 0 0 0 .06.86l.27-.27a5.79 5.79 0 0 1 .78-2.9 5.78 5.78 0 0 0 .63-3.4A12.87 12.87 0 0 1 12 8.33a1.92 1.92 0 0 1 .28.8 2.18 2.18 0 0 1-.55 1.57.85.85 0 0 0-.2.79c0 .11.16.53.25.8.35-.73 1.33-1.14 1.77-1.75a2.72 2.72 0 0 1-.82 1.94l-.32.33a8.79 8.79 0 0 0-1.5 1.76 2 2 0 0 0-.23.53 7 7 0 0 0-.26 1.31c-.06.41-.13.89-.15 1.11 0 .49-.19 1.27-.77 1.5h-.09c-.55.12-1.11-.36-1.52-1.23a1 1 0 0 1-.27.17c.55 1.38 1.38 2 2.11 2 .55 0 1-.29 1.13-1.15.07-.43.12-.9.16-1.37a10.53 10.53 0 0 1 .32-1.93 9.18 9.18 0 0 1 1.56-1.81 4.11 4.11 0 0 0 .87-1.31c.45-.87-.1-2.93-.21-3.31a3.46 3.46 0 0 1-.89.9 2.15 2.15 0 0 0 .06-1.29v-.04c-.39-1.37-1.73-2.59-2.32-3.29-.78-.92-.52-1.5-.23-1.88.05.09.11.17.17.26A41.9 41.9 0 0 1 14.47 10a8.27 8.27 0 0 1 .58 1.69c.41 2.37-1.16 4.79-3.52 4.11a7.75 7.75 0 0 0-.18 1 2.92 2.92 0 0 0 1.12.27h.08c1.94 0 3.46-1.51 3.18-4.72a9.21 9.21 0 0 0-.77-2.73 33.1 33.1 0 0 0-4.18-6.49A4.47 4.47 0 0 1 10 1.78a1.47 1.47 0 0 1 .22-1.54 1.06 1.06 0 0 1 .21-.16V0a.55.55 0 0 0-.29.14zM7.93 5.48a.61.61 0 1 0 .59.59.59.59 0 0 0-.59-.59z"></path></svg>
                                <div class="writeInfo">
                                    <p class="writter">${news.author}</p>
                                    <p id="date">${news.date}</p>
                                </div>
                            </div>
                            <img src="icon/share.png" alt="" class="share">
                        </div>
                    </div>
            </div>
            `
            html += li
        });

        newsList.innerHTML = html
    }else{
        newsList.innerHTML = '<h1>يرجى تسجيل الدخول لرؤية المحتوى</h1>'
    }
}

let d = new Date()
let months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']

let nowDate = `${d.getFullYear()}, ${months[d.getMonth()]} ${d.getDate()}`

//sing-up form step submit
const steps = Array.from( document.querySelectorAll('.step')) 

const nextBtn = document.querySelector('#next')
const prevBtn = document.querySelector('#prev')
const form = document.querySelector('form')

if(nextBtn){
  nextBtn.addEventListener('click', (e) => {
    changeStep('next')
  })
}

if(prevBtn){
  prevBtn.addEventListener('click', (e) => {
    changeStep2('prev')
  })
}

let changeStep = (btn) => {
  let index = 0
  let active = document.querySelector('.active')
  index = steps.indexOf(active)
  steps[index].classList.remove('active')
  if(btn === 'next'){
    index++
  }
  steps[index].classList.add('active')
}

if(prevBtn){

  nextBtn.addEventListener('click', (e) => {

    changeStep('prev')
  })
}

let changeStep2 = (btn) => {
  let index = 1
  let active = document.querySelector('.active')
  index = steps.indexOf(active)
  steps[index].classList.remove('active')
  if(btn === 'prev'){
    index--
  }
  steps[index].classList.add('active')
}


//account form step submit

const sliders = Array.from( document.querySelectorAll('.slider')) 

const nBtn = document.querySelector('.account-name')
const pBtn = document.querySelector('.back')
const lform = document.querySelector('.menu')

if(nBtn){
  nBtn.addEventListener('click', (e) => {
    changeAcc('next')
  })
}

if(pBtn){
  pBtn.addEventListener('click', (e) => {
    changeAcc2('prev')
  })
}

let changeAcc = (btn) => {
  let index = 0
  let active = document.querySelector('.active')
  index = sliders.indexOf(active)
  sliders[index].classList.remove('active')
  if(btn === 'next'){
    index++
  }
  sliders[index].classList.add('active')
}

if(pBtn){

  nBtn.addEventListener('click', (e) => {

    changeAcc('prev')
  })
}

let changeAcc2 = (btn) => {
  let index = 1
  let active = document.querySelector('.active')
  index = sliders.indexOf(active)
  sliders[index].classList.remove('active')
  if(btn === 'prev'){
    index--
  }
  sliders[index].classList.add('active')
}

const menuicon = document.querySelector('.menuicon')
if(menuicon){
  menuicon.addEventListener('click', (e) => {
    let menu = document.querySelector('.menu-container')
    menu.classList.toggle('open')
  })
}

const close = document.querySelector('.close')

if(close){

  close.addEventListener('click', (e) => {
    let menu = document.querySelector('.menu-container')
    menu.classList.toggle('open')
  })
}

//dark light them
const lightBtn = document.querySelector('.light')
const darkBtn = document.querySelector('.dark')
const autoBtn = document.querySelector('.auto')


let them = localStorage.getItem('them')

if(them){
  document.documentElement.setAttribute('data-them', them)
}


if(lightBtn){

lightBtn.addEventListener('click', (e) => {
  trans()
  localStorage.setItem('them', 'light')
  document.documentElement.setAttribute('data-them', 'light')
})
} 

if(darkBtn){
darkBtn.addEventListener('click', (e) => {
  trans()
  localStorage.setItem('them', 'dark')
  document.documentElement.setAttribute('data-them', 'dark')
})
} 

if(autoBtn){

  autoBtn.addEventListener('click', (e) => {

    let date = new Date()
    let now = date.getHours()
    
    if(now >= 7){
      trans()
      localStorage.setItem('them', 'dark')
      document.documentElement.setAttribute('data-them', 'dark')
    }else if(now  >= 19){
      trans()
      localStorage.setItem('them', 'light')
      document.documentElement.setAttribute('data-them', 'light')
    }
  })
}

let trans = () => {
            document.documentElement.classList.add('transition');
            window.setTimeout(() => {
                document.documentElement.classList.remove('transition')
            }, 1000)
}